// Crear dos variables numéricas
let num1 = 8
let num2 = 12

// Utilizar el operador suma para guardar el valor de la suma en una 3er variable
let sum = num1 + num2

// Imprimir el resultado
console.log("La suma de num1 y num2 es:", sum)

// Crear dos variables de tipo String
let str1 = "Hola";
let str2 = "Mundo";

// Concatenarlas y guardar el resultado en una 3er variable
let concatenatedString = str1 + " " + str2;

// Imprimir el resultado
console.log('El resultado de concatenar str1 y str2 es:', concatenatedString);

// Crear dos variables de tipo String
let string1 = "JavaScript";
let string2 = "Programming";

// Sumar el largo de cada variable y guardar el resultado en una 3er variable
let totalLength = string1.length + string2.length;

// Imprimir el resultado
console.log('La suma del largo de string1 y string2 es:', totalLength);